#!/bin/bash
# fwgateway（专线防火墙网关）v1.0 一键安装脚本（root 执行）
# 自动完成：安装二进制 → 建系统用户与数据目录 → 自签证书 → 配置与 systemd
# 单元（含每日备份 timer）→ 内核参数基线（ip_forward/conntrack 容量）→
# 启动自检。
# 重复安装安全：配置/证书/数据库不会被误改——可当升级脚本用（restart 载入新二进制）。
#
# 相对 0.x 的行为变化：
#  - 不再收紧整机 FORWARD 默认策略——v1 的「白名单外全拒」由服务自有
#    nftables 规则链承担（只管本产品辖区），与 docker/firewalld/iptables
#    共存（legacy 并存的 FORWARD DROP 宿主会在服务日志看到明确的冲突提示）
#  - 依赖精简：iptables 已不再必需（nftables netlink 直连）；tc 与 conntrack
#    仍被限速/掐断功能使用（缺失时对应功能自动降级、日志提示，不阻塞安装）
set -eu

usage() {
  echo "用法: sudo $0 [--port 8443] [--data-dir /var/lib/haproxyweb] [--external-ip 1.2.3.4] [--tune-10g]"
  echo "  --port          管理后台监听端口（默认 8443）"
  echo "  --data-dir      数据目录（默认 /var/lib/haproxyweb；重复安装不传参则沿用）"
  echo "  --external-ip   写入自签证书 SAN 的访问 IP（默认自动取首个非回环地址）"
  echo "  --tune-10g      附加万兆转发调优（conntrack 50 万会话容量等，见 tuning-10g.md）"
  exit 1
}

PORT=8443
DATA_DIR=/var/lib/haproxyweb
EXTERNAL_IP=""
TUNE_10G=0
EXPLICIT_PORT=0
EXPLICIT_DATA_DIR=0

while [ $# -gt 0 ]; do
  case "$1" in
    --port) PORT="$2"; EXPLICIT_PORT=1; shift 2 ;;
    --data-dir) DATA_DIR="$2"; EXPLICIT_DATA_DIR=1; shift 2 ;;
    --external-ip) EXTERNAL_IP="$2"; shift 2 ;;
    --tune-10g) TUNE_10G=1; shift ;;
    -h|--help) usage ;;
    *) usage ;;
  esac
done

if [ "$(id -u)" -ne 0 ]; then
  echo "错误：请以 root 运行（sudo $0）" >&2
  exit 1
fi

SCRIPT_DIR=$(cd "$(dirname "$0")" && pwd)

# ---------- 架构与二进制 ----------
ARCH=$(uname -m)
if [ "$ARCH" != "x86_64" ]; then
  echo "错误：本部署包仅支持 x86_64，当前架构 $ARCH" >&2
  exit 1
fi
BIN_SRC="$SCRIPT_DIR/haproxyweb-linux-amd64"
if [ ! -f "$BIN_SRC" ]; then
  echo "错误：找不到二进制 $BIN_SRC（请在解包目录内运行本脚本）" >&2
  exit 1
fi
echo "==> 安装二进制到 /usr/local/bin/haproxyweb"
install -m 0755 "$BIN_SRC" /usr/local/bin/haproxyweb

# ---------- 系统用户与目录 ----------
if ! id haproxyweb >/dev/null 2>&1; then
  echo "==> 创建系统用户 haproxyweb"
  useradd --system --home "$DATA_DIR" --shell /usr/sbin/nologin haproxyweb
fi
mkdir -p "$DATA_DIR" /etc/haproxyweb
chown haproxyweb:haproxyweb "$DATA_DIR"
chmod 0700 "$DATA_DIR"

# ---------- 内核参数基线（幂等）：转发 + conntrack ----------
KCONF=/etc/sysctl.d/99-haweb-10g.conf
sysctl_key() { cat "/proc/sys/${1//./\/}" 2>/dev/null || echo "?"; }
mkdir -p /etc/sysctl.d
[ -f "$KCONF" ] || : > "$KCONF"
if [ "$(sysctl_key net.ipv4.ip_forward)" != "1" ]; then
  echo "net.ipv4.ip_forward = 1" >> "$KCONF"
  echo 1 > /proc/sys/net/ipv4/ip_forward
  echo "==> net.ipv4.ip_forward=1（转发前提）"
fi
if [ "$(sysctl_key net.netfilter.nf_conntrack_max)" -lt 524288 ] 2>/dev/null; then
  echo "net.netfilter.nf_conntrack_max = 524288" >> "$KCONF"
  echo 524288 > /proc/sys/net/netfilter/nf_conntrack_max 2>/dev/null || \
    echo "    提示：nf_conntrack 模块未加载，容量参数将在首次转发时按需生效"
  echo "==> nf_conntrack_max=524288（50 万会话）"
fi
if [ "$TUNE_10G" = "1" ] && [ -f "$SCRIPT_DIR/tuning-10g.sh" ]; then
  echo "==> 附加万兆调优（--tune-10g）"
  sh "$SCRIPT_DIR/tuning-10g.sh" || true
fi

# ---------- 自签证书（已有则跳过） ----------
if [ ! -f /etc/haproxyweb/tls/key.pem ]; then
  if [ -z "$EXTERNAL_IP" ]; then
    EXTERNAL_IP=$(ip -4 addr show scope global 2>/dev/null | awk '/inet /{print $2}' | cut -d/ -f1 | head -1)
  fi
  SAN="IP:127.0.0.1,DNS:localhost"
  [ -n "$EXTERNAL_IP" ] && SAN="$SAN,IP:$EXTERNAL_IP"
  echo "==> 生成自签证书（SAN: $SAN）——浏览器首次访问需信任一次"
  mkdir -p /etc/haproxyweb/tls
  openssl req -x509 -newkey rsa:2048 -nodes -days 825 \
    -keyout /etc/haproxyweb/tls/key.pem -out /etc/haproxyweb/tls/cert.pem \
    -subj "/CN=${EXTERNAL_IP:-haproxyweb}" -addext "subjectAltName=$SAN" 2>/dev/null
fi
chown -R haproxyweb:haproxyweb /etc/haproxyweb
chmod 0600 /etc/haproxyweb/tls/key.pem

# ---------- 配置（已有不覆盖；缺省参数沿用已装配置——防升级切空库） ----------
if [ ! -f /etc/haproxyweb/config.yaml ]; then
  echo "==> 部署配置（监听 :$PORT，数据目录 $DATA_DIR）"
  sed -e "s|^  data_dir: .*|  data_dir: \"$DATA_DIR\"|" \
      -e "s|^  listen: .*|  listen: \":$PORT\"|" \
      "$SCRIPT_DIR/deploy/config.example.yaml" > /etc/haproxyweb/config.yaml
else
  CUR_LISTEN=$(grep -E '^  listen:' /etc/haproxyweb/config.yaml | head -1 | sed 's/.*"\(.*\)".*/\1/')
  CUR_DATA=$(grep -E '^  data_dir:' /etc/haproxyweb/config.yaml | head -1 | sed 's/.*"\(.*\)".*/\1/')
  if [ "$EXPLICIT_DATA_DIR" != "1" ] && [ -n "$CUR_DATA" ] && [ "$CUR_DATA" != "$DATA_DIR" ]; then
    echo "==> 沿用已有数据目录 $CUR_DATA（如需变更请显式传 --data-dir）"
    DATA_DIR="$CUR_DATA"
  fi
  if [ "$EXPLICIT_PORT" != "1" ] && [ -n "$CUR_LISTEN" ]; then
    case "$CUR_LISTEN" in *:*) PORT="${CUR_LISTEN#*:}" ;; esac
    echo "==> 沿用已有监听端口 :$PORT（如需变更请显式传 --port）"
  fi
  if [ "$EXPLICIT_DATA_DIR" = "1" ] && [ -n "$CUR_DATA" ] && [ "$CUR_DATA" != "$DATA_DIR" ]; then
    echo "    警告：数据目录将由 $CUR_DATA 变更为 $DATA_DIR（原数据不迁移，服务将使用新空库）"
  fi
  echo "==> 更新已有配置（监听 :$PORT，数据目录 $DATA_DIR）"
  sed -i -e "s|^server:.*|web:|" \
         -e "s|^  listen: .*|  listen: \":$PORT\"|" \
         -e "s|^  data_dir: .*|  data_dir: \"$DATA_DIR\"|" /etc/haproxyweb/config.yaml
fi
chown root:haproxyweb /etc/haproxyweb/config.yaml
chmod 0640 /etc/haproxyweb/config.yaml

# ---------- systemd 单元（始终刷新包内最新版） ----------
echo "==> 部署 systemd 单元与备份 timer"
mkdir -p /usr/local/share/haproxyweb
install -m 0755 "$SCRIPT_DIR/deploy/backup.sh" /usr/local/share/haproxyweb/backup.sh
sed -e "s|^WorkingDirectory=.*|WorkingDirectory=$DATA_DIR|" \
    -e "s|^Environment=HAWEB_DATA_DIR=.*|Environment=HAWEB_DATA_DIR=$DATA_DIR|" \
    -e "s|^ReadWritePaths=.*|ReadWritePaths=$DATA_DIR|" \
    "$SCRIPT_DIR/deploy/haproxyweb.service" > /etc/systemd/system/haproxyweb.service
sed -e "s|^Environment=HAWEB_DATA_DIR=.*|Environment=HAWEB_DATA_DIR=$DATA_DIR|" \
    -e "s|^ReadWritePaths=.*|ReadWritePaths=$DATA_DIR|" \
    "$SCRIPT_DIR/deploy/haproxyweb-backup.service" > /etc/systemd/system/haproxyweb-backup.service
install -m 0644 "$SCRIPT_DIR/deploy/haproxyweb-backup.timer" /etc/systemd/system/

# ---------- 0.x 升级清理：旧网关基线单元废弃（v1 不再整机收紧 FORWARD） ----------
if systemctl list-unit-files 2>/dev/null | grep -q haproxyweb-gateway; then
  systemctl disable --now haproxyweb-gateway >/dev/null 2>&1 || true
  rm -f /etc/systemd/system/haproxyweb-gateway.service
  echo "==> 已移除 0.x 的 gateway-firewall 基线单元（v1 默认拒绝由服务自身 nftables 规则承担）"
  echo "    提示：0.x 曾把整机 FORWARD 默认策略收紧为 DROP；如需放开请评估后执行"
  echo "          iptables -P FORWARD ACCEPT（v1 无需整机 DROP 基线）"
fi

# ---------- 备份依赖（可选） ----------
if ! command -v sqlite3 >/dev/null 2>&1; then
  echo "==> 安装 sqlite3（每日备份依赖）"
  (apt-get install -y sqlite3 -q 2>/dev/null || yum install -y sqlite 2>/dev/null) \
    || echo "    自动安装失败，请手动安装（仅影响每日备份，不影响网关本身）"
fi

# ---------- 启动 ----------
echo "==> 启动服务与每日备份"
systemctl daemon-reload
systemctl enable haproxyweb haproxyweb-backup.timer >/dev/null 2>&1
# 升级场景：restart 载入新二进制（enable --now 不会重启已运行服务）
if systemctl is-active --quiet haproxyweb; then
  systemctl restart haproxyweb
else
  systemctl start haproxyweb
fi
systemctl start haproxyweb-backup.timer 2>/dev/null || true
chown -R haproxyweb:haproxyweb "$DATA_DIR" 2>/dev/null || true
sleep 2
if systemctl is-active --quiet haproxyweb; then
  ACCESS_IP="${EXTERNAL_IP:-127.0.0.1}"
  echo
  echo "============================ 安装完成 ============================"
  echo "  管理后台:   https://$ACCESS_IP:$PORT （自签证书，浏览器信任一次）"
  echo "  默认账号:   admin / admin123 （首次登录强制改密）"
  echo "  功能入口:   端口映射 / SNAT 穿越 / 端口发布 / 防火墙策略 /"
  echo "              出口管理（多出口主备/分担）/ 会话表"
  echo "  服务管理:   systemctl status|restart|stop haproxyweb"
  echo "  修改配置:   /etc/haproxyweb/config.yaml → systemctl restart"
  echo "  每日备份:   $DATA_DIR/backups/（03:00，保留 30 份）"
  echo "  升级重装:   解包新版本后重跑本脚本（数据/配置自动沿用）"
  echo "================================================================="
  echo "快速验证:"
  echo "  curl -sk https://127.0.0.1:$PORT/healthz | head -c 200"
  echo "  journalctl -u haproxyweb -e | tail（看 nftables 基座日志/冲突提示）"
else
  echo "错误：服务启动失败：journalctl -u haproxyweb -e" >&2
  echo "常见原因：iptables-legacy 宿主与 FORWARD DROP 并存（日志有 fail-fast 指引）" >&2
  exit 1
fi
