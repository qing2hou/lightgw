#!/bin/sh
# 轻量专线网关卸载：停服务与 timer → 删二进制/单元/配置/证书。
# 数据目录默认保留；--purge 才删除（不可逆，先确认已导出备份）。
set -eu

PURGE=0
[ "${1:-}" = "--purge" ] && PURGE=1

if [ "$(id -u)" -ne 0 ]; then
  echo "错误：请以 root 运行" >&2
  exit 1
fi

echo "==> 停止服务"
systemctl disable --now haproxyweb.service haproxyweb-backup.timer haproxyweb-gateway.service 2>/dev/null || true
systemctl stop haproxyweb.service 2>/dev/null || true

echo "==> 删除文件"
rm -f /etc/systemd/system/haproxyweb.service \
      /etc/systemd/system/haproxyweb-backup.service \
      /etc/systemd/system/haproxyweb-backup.timer \
      /etc/systemd/system/haproxyweb-gateway.service \
      /usr/local/bin/haproxyweb \
      /usr/local/share/haproxyweb/backup.sh \
      /usr/local/share/haproxyweb/gateway-firewall.sh
rm -rf /etc/haproxyweb /usr/local/share/haproxyweb
systemctl daemon-reload
# 网关基线说明：FORWARD 默认策略保持 DROP 不自动放开（卸载后机器不再受管，
# 收紧态更安全——如需放开请手工 iptables -P FORWARD ACCEPT）；
# /etc/sysctl.d/99-haproxyweb-gateway.conf（ip_forward=1）保留——其他转发可能依赖

if [ "$PURGE" = 1 ]; then
  echo "==> --purge：删除数据目录 /var/lib/haproxyweb（含数据库与备份，不可逆）"
  rm -rf /var/lib/haproxyweb
else
  echo "==> 保留数据目录 /var/lib/haproxyweb（需要删除请加 --purge）"
fi
echo "卸载完成"
